import 'package:flutter/cupertino.dart';

double fixPadding = 10.0;

SizedBox heightSpace = SizedBox(height: 10.0);
SizedBox widthSpace = SizedBox(width: 10.0);
dynamic headingSize = 16.0;
dynamic titleSize = 14.0;

final apiKey = 'AIzaSyB2kvOckQn8vJlqi8PPnbOzK5dCf-xg3eQ';
