class BackLatLng{
  dynamic lat;
  dynamic lng;

  BackLatLng(this.lat, this.lng);

  @override
  String toString() {
    return 'BackLatLng{lat: $lat, lng: $lng}';
  }
}